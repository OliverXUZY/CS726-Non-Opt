## HW3

In this question I use python and submitted it jupyter notebook file. I use **Numpy**, **Pandas** and **matplotlib** module. I only use **Pandas** module to construct data frame for better plotting.



Use Shift+Return to run code in each cell. The code, plot, text description are all inclusive in the notebook file.

